#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Brian Torretta
# Date:  Nov 17, 2018
# ChangeLog: (Who, When, What)
#
#  Brian, 11/17 change key/value loop through in initial data load to a string position.
#  Brian, 11/17 moved to a named key value for the dictionary to later find items to delete using it
#  Brian, 11/18 added delete item function by using dict keys and iterating over the length of the list. Added a range so we know to start at zero.
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------

#-- Data --#
#load data manually into file. Then open a filehandle as python has these modes as totally separate
objFileName = open("Todo.txt","w")
objFileName.write("Clean house,low\n")
objFileName.write("Pay bills,low\n")
objFileName.close()
objFileName = open("Todo.txt","r")

#declare starting dictionary and permanent table that will be used throughout, so I need to keep the table global and outside a function scope

dicRow = {}
lstTable = []

# Load data from a filehandle
    # When the program starts, load each "row" of data
    # in "ToDo.txt" into a python Dictionary.
    # Add the each dictionary "row" to a python list "table"


#-- Processing --These functions are explicitly called.
for row in objFileName:
    #on each row, the dict is comma seperated, then finding task or pri based on the split position
    strTask = row.split(',')[0]
    strPri = row.split(',')[1]
    #strips off the training /n and assigns it to the same variable
    strPri = strPri[:-1]
    dicRow = {"todo": strTask, "priority": strPri}
    lstTable.append(dicRow)

def loadcurrent():
    print(lstTable)

def addnew():
    strNewTask = input("Please enter a TODO")
    strNewPriority = input("The priority")
    newdicRow = {"todo": strNewTask, "priority": strNewPriority}
    lstTable.append(newdicRow)
    print(lstTable)

def deleteitem():
    strDelTask = input("What Task do you want to delete?")

    #TODO document. This clued me in to search by key, the second answer specifically
    # :https://stackoverflow.com/questions/8653516/python-list-of-dictionaries-search
    #range and len: https://docs.python.org/2/tutorial/datastructures.html#dictionaries
    for index in range(len(lstTable)):
        # print(i)
        if lstTable[index]["todo"] == strDelTask:
            # print(i)
            del lstTable[index]
            print(lstTable)
            # this break avoid an out of bounds error on the next loop when an item is deleted as positions of index has changed
            break

def savetofile():
    #This is a mostly academic use of the try except. You could really trigger the error if you choose a path here that would be illegal to the filesystem
    try:
        with open('Todo.txt', 'w') as f:
            for item in lstTable:
                f.write("%s\n" % item)
    except IOError:
        print("Not a possible path, please try again")

# Input from user, aka presentation

while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()#adding a new line

# Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        loadcurrent()
        #continue

        #for obj in lstTable:
        #    print(obj)
    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
       addnew()
    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
       deleteitem()
    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
       savetofile()
    elif (strChoice == '5'):
        break #and Exit the program
    else: print("please pick a number 1-5")

