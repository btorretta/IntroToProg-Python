#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  Sept 16, 2017
# ChangeLog: (Who, When, What)
#   RRoot, 09/16/2017, Created Script
#   Brian Torretta, 11/23/2018, initial modification, added functions in an attempt at encapsulation, added object type class, added several docstrings. 11/24 implemented main()
#   Brian Torretta 11/26/2018 found bug that was causing shaddow variables. Implemented globals in function.

#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------

class ToDo(object):
    """
    This class inherits the object class and can access the functions as attributes using the staticmethod decorator
    """

    @staticmethod
    def main():
        # Data
        # We are maintaining these as a global variable set
        global objFileName
        objFileName = "Todo.txt"
        global strData
        strData = ""
        global dicRow
        dicRow = {}
        global lstTable
        lstTable = []


        # This is the initial data loading into the list from the file
        objFile = open(objFileName, "r")
        for line in objFile:
            strData = line.split(",")  # readline() reads a line of the data into 2 elements
            dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
            lstTable.append(dicRow)
            # This needs to be kept open for later function access
            # objFile.close()



    # processing
    @staticmethod
    #def AddTask(lstTable):
    def AddTask(*args):
        global lstTable
        global dicRow
        global strData
        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        dicRow = {"Task": strTask, "Priority": strPriority}
        lstTable.append(dicRow)
        #printer = ToDo.PrintCurrentData(lstTable)
        #This return statement isn't a functional requirement as we are using a global list. However it is meant to use the input/output encapsulation model if we get to the point of using the return value and not a print function.
        #return printer
        return ToDo.PrintCurrentData(lstTable)

    @staticmethod
    #def RemoveTask(lstTable):
    def RemoveTask(*args):
        global lstTable
        global dicRow
        global strData
        strKeyToRemove = input("Which TASK would you like removed? - ")
        blnItemRemoved = False  # Creating a boolean Flag
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if (strKeyToRemove == str(
                    list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list!
                # added a lowercase attribute for the string to use
                del lstTable[intRowNumber]
                blnItemRemoved = True
            # end if
            intRowNumber += 1
        # end for loop
        # 5b-Update user on the status
        if (blnItemRemoved == True):
            print("The task was removed.")
        else:
            print("I'm sorry, but I could not find that task.")

        # 5c Show the current items in the table
        ToDo.PrintCurrentData(lstTable)
        #This isn't strictly required, just being explicit about the return value if in case we need to be sure at a later date
        return(lstTable)
    @staticmethod
    #def SavetoFile(lstTable):
    def SavetoFile(*args):
        global lstTable
        global dicRow
        global strData
        ToDo.PrintCurrentData(lstTable)
        # 5b Ask if they want save that data
        if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
            objFile = open(objFileName, "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            input("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")
            return

    @staticmethod
    def exit(message):
        print(message)
        raise SystemExit

    #Presentation - Display a menu of choices to the user or print
    @staticmethod
    #def PrintCurrentData(lstTable):
    #def PrintCurrentData():
    def PrintCurrentData(*args):

        """
        :param lstTable:
        :return:
        This function saved a lot of re-doing of formatting code
        """
        global lstTable
        global dicRow
        global strData
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        #This isn't strictly required, just being explicit about an expectation of none return type
        return
    @staticmethod
    def presentation():
        global lstTable
        global dicRow
        global strData
        while (True):
            print("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)
            strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
            print()  # adding a new line

            # Step 3
            # Show the current items in the table
            if (strChoice.strip() == '1'):
                ToDo.PrintCurrentData(lstTable)

            # Step 4
            # Add a new item to the list/Table
            elif (strChoice.strip() == '2'):
                ToDo.AddTask(lstTable)
                continue  # to show the menu

            # Step 5
            # Remove a new item to the list/Table
            elif (strChoice == '3'):
                ToDo.RemoveTask(lstTable)
                continue  # to show the menu

            # Step 6
            # Save tasks to the ToDo.txt file
            elif (strChoice == '4'):
                # 5a Show the current items in the table
                ToDo.SavetoFile(lstTable)
                continue  # to show the menu
            elif (strChoice == '5'):
                ToDo.exit(message="Thanks for playing")


#load the application presentation layer and allow it to access the processing functions from there
p = ToDo()
p.main()
ToDo.presentation()




