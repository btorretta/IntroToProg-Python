#-------------------------------------------------#
# Title: A simple pickling
# Dev:   Brian Torretta
# Date:  12/1/2018
# ChangeLog: (Who, When, What)
#   Brian Torretta, 12/01/2018, Created Script
#
#-------------------------------------------------#

#A simple script to test if a file is in valid pickle format or not

import pickle

#data
objfile = ''

#process
def openupthefile(objfile):
    """"
    :objfile is a filehandle variable
    """
    try:
        objfile = open(objfile, "rb")
        objfiledata = pickle.load(objfile)
        #objfile.close()
        print(objfiledata)
        print("pickled file")
        return objfile
    except FileNotFoundError:
        return print("no file found")
    except pickle.UnpicklingError:
        return print("not a pickled file")
    except EOFError:
        return print("Looks like an empty file")

#present
def present():
    objfile = input("whats the file name?")
    openupthefile(objfile)

present()