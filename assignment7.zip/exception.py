#-------------------------------------------------#
# Title: A simple try except block
# Dev:   Brian Torretta
# Date:  12/1/2018
# ChangeLog: (Who, When, What)
#   Brian Torretta, 12/01/2018, Created Script. Added functions to better break into data, processing and presentation
#
#-------------------------------------------------#
# Due to trapping on a keyboard signal, the exception isn't possible to trip using pycharms run window. More info here: https://stackoverflow.com/questions/39796689/why-doesnt-this-python-keyboard-interrupt-work-in-pycharm/39796898
#Data, sort of boring, not much data

kb = ''

#presentation
def prettyprint(kb):
    print("Parrot says:\n" + kb)

#processing
def trythis():
    try:
        print("*********Welcome to my parrot app*******\n")
        kb = input("input anything except control c")
        prettyprint(kb)
    except KeyboardInterrupt:
        print("I told you not to!")
    finally: print("we arrive here no matter what")

trythis()