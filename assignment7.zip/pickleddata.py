#-------------------------------------------------#
# Title: A simple pickling
# Dev:   Brian Torretta
# Date:  12/1/2018
# ChangeLog: (Who, When, What)
#   Brian Torretta, 12/01/2018, Created Script
#
#-------------------------------------------------#

#A simple script to load picked data and open it open and print it to screen
import pickle

#Data
pickledict = {}

#presentation

try:
    StrGrocery = input("What was an item you bought from the grocery?")
    IntPrice = int(input("Enter the price of that grocery"))
    pickledict[StrGrocery] = IntPrice
except ValueError:
    print("Wrong value type for the price, try an integer")

#processing
#this opens an appendable binary file for pickling
objfile = open("catfood.dat", "ab")
#put the dict into the file
pickle.dump(pickledict, objfile)
objfile.close()

#reading the binary
objfile = open("catfood.dat", "rb")
objfiledata = pickle.load(objfile)
objfile.close()

print(objfiledata)